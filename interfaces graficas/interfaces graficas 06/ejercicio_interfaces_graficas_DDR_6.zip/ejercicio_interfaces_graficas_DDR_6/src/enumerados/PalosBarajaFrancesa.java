package enumerados;

public enum PalosBarajaFrancesa { 
    DIAMANTES,
    PICAS,
    TREBOLES,
    CORAZONES,
    JOKER;
}
