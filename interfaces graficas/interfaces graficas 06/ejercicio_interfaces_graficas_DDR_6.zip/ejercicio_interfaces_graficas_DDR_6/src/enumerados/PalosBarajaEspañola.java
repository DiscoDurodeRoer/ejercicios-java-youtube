package enumerados;

public enum PalosBarajaEspañola {
    OROS,
    COPAS,
    ESPADAS,
    BASTOS;
}
